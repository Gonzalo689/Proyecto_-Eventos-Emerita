package com.example.android_eventosemerita.fragments_nav

import android.app.AlertDialog
import android.content.Context
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import android.content.Intent
import android.graphics.Bitmap.CompressFormat
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.android_eventosemerita.R
import com.example.android_eventosemerita.api.Callback
import com.example.android_eventosemerita.api.UserAPIClient
import com.example.android_eventosemerita.api.model.Event
import com.example.android_eventosemerita.databinding.FragmentProfileBinding
import com.example.android_eventosemerita.login.SignIn
import com.example.android_eventosemerita.utils.ImageCircle
import com.example.android_eventosemerita.utils.UtilsConst.NOTIF
import com.example.android_eventosemerita.utils.UtilsConst.REMEMBER
import com.example.android_eventosemerita.utils.UtilsConst.USER_ID
import com.example.android_eventosemerita.utils.UtilsConst.userRoot
import com.example.android_eventosemerita.utils.UtilsFun.addNotification
import com.example.android_eventosemerita.utils.UtilsFun.lowerQuality
import com.squareup.picasso.MemoryPolicy
import com.squareup.picasso.Picasso
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream


class Profile : Fragment() {
    companion object{
        //const val NOTIF = "notification"
    }
    private lateinit var binding: FragmentProfileBinding
    private lateinit var uri : Uri
    private lateinit var userAPIClient: UserAPIClient
    private var deployEdit = false
    private var galleryOpened = false
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            this.uri = it
//            Picasso.get()
//                .load(it)
//                .transform(ImageCircle())
//                .into(binding.profileimage)
            galleryOpened = true

        }
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?

    ): View? {
        userAPIClient = UserAPIClient(requireContext())
        binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.logOut.setOnClickListener(View.OnClickListener {
            forgotUser()
            returnToSplash()

        })
        binding.galery.setOnClickListener(View.OnClickListener {
            openGalery()
        })


        binding.save.setOnClickListener(View.OnClickListener {
            //updateImage()
        })
        binding.switchNotf.setOnClickListener {
            val preferences = androidx.preference.PreferenceManager.getDefaultSharedPreferences(requireContext())
            val editor = preferences.edit()
            if (binding.switchNotf.isChecked){
                editor.putBoolean(NOTIF, true)
            }else{
                editor.putBoolean(NOTIF, false)
            }
            editor.apply()
            getEventFavs()
        }

        binding.edit.setOnClickListener {
            if (deployEdit){
                changeIconDeploy(R.drawable.ic_arrow_up)
                deployEdit = false
                binding.editProfile.visibility = View.GONE
            }else{
                changeIconDeploy(R.drawable.ic_arrow_down)
                deployEdit = true
                binding.editProfile.visibility = View.VISIBLE
            }
        }

        remenberNotf()
        editProfie()
    }
    private fun editProfie(){
        if (userRoot == null){
            return
        }
        image(userRoot!!.profilePicture)
        binding.editEmail.hint = userRoot!!.email
        binding.editName.hint = userRoot!!.nombre


    }


    fun changeIconDeploy(ic:Int){
        val newDrawable = ContextCompat.getDrawable(requireContext(), ic)
        binding.editTextArrow.setCompoundDrawablesWithIntrinsicBounds(null,null,newDrawable,null)

    }

    fun remenberNotf(){
        val preferences = androidx.preference.PreferenceManager.getDefaultSharedPreferences(requireContext())
        binding.switchNotf.isChecked = preferences.getBoolean(NOTIF,true)
    }
    fun getEventFavs(){
        userAPIClient.getFavEventsList(userRoot!!.id, object : Callback.MyCallback<List<Event>> {
            override fun onSuccess(data: List<Event>){
                if (data.isNotEmpty()){
                    for (event in data){
                        addNotification(true, event,requireContext())
                    }
                }
            }

            override fun onError(errorMsg: List<Event>?) {
            }
        })
    }

    fun updateImage(imageString: String){
        binding.progressBar.visibility = View.VISIBLE
        userAPIClient.updateProfilePicture(userRoot!!.id, imageString, object : Callback.MyCallback<String> {
            override fun onSuccess(data: String) {
                activity?.runOnUiThread {
                    val file = File(requireContext().cacheDir, "image.jpg")
                    binding.progressBar.visibility = View.GONE
                    Picasso.get()
                        .load(file)
                        .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
                        .into(binding.profileimage)
                }
            }

            override fun onError(errorMsg: String?) {
                activity?.runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                }
            }
        })
    }
    fun showFullImageFromCache(file: File, imageString: String) {
        val dialogBuilder = AlertDialog.Builder(requireContext())
        val imageView = ImageView(requireContext())
        imageView.adjustViewBounds = true

        Picasso.get()
            .load(file)
            .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
            .into(imageView)

        dialogBuilder.setView(imageView)

        dialogBuilder.setPositiveButton("Galery") { dialog, which ->
            openGalery()
            dialog.dismiss()
        }
        dialogBuilder.setNeutralButton("Cancelar") { dialog, which ->
            dialog.dismiss()
        }
        dialogBuilder.setNegativeButton("Guardar") { dialog, which ->
            updateImage(imageString)
            dialog.dismiss()
        }
        val alertDialog = dialogBuilder.create()
        alertDialog.show()

    }

    fun decodeBase64ToFile(base64Image: String) :File{
        val file = File(requireContext().cacheDir, "image.jpg")
        if (file.exists()) {
            file.delete()
        }
        val decodedBytes = Base64.decode(base64Image, Base64.DEFAULT)
        file.writeBytes(decodedBytes)
        return file
    }
    fun image(img:String): File {
        var file = File(requireContext().cacheDir, "image.jpg")
        if (img.isNotEmpty()){
            file = decodeBase64ToFile(img)
            Picasso.get()
                .load(file)
                .memoryPolicy(MemoryPolicy.NO_CACHE, MemoryPolicy.NO_STORE)
                .transform(ImageCircle())
                .into(binding.profileimage)
            binding.profileimage.setOnClickListener{
                showFullImageFromCache(file,img)
            }
        }else{
            Picasso.get()
                .load(R.drawable.prueba)
                .transform(ImageCircle())
                .into(binding.profileimage)
        }
        return file
    }

    fun forgotUser(){
        val preferences = androidx.preference.PreferenceManager.getDefaultSharedPreferences(requireContext())
        val editor = preferences.edit()
        editor.putBoolean(REMEMBER, false)
        editor.putInt(USER_ID, 0)
        editor.apply()
    }
    fun returnToSplash(){
        val intent = Intent(requireContext(), SignIn::class.java)
        startActivity(intent)
        requireActivity().finish()
    }
    private fun convertToBytes(path: Uri): ByteArray? {
        val format = if (Build.VERSION.SDK_INT >= 30) CompressFormat.WEBP_LOSSLESS else CompressFormat.WEBP
        val outputStream = ByteArrayOutputStream()
        return try {
            val inputStream: InputStream? = requireContext().contentResolver?.openInputStream(path)
            val bitmap = BitmapFactory.decodeStream(inputStream)
            bitmap.compress(format, 100, outputStream)
            return outputStream.toByteArray()
        } catch (e: Exception) {
            null
        }
    }
    private fun openGalery(){
        galleryLauncher.launch("image/*")

    }
    override fun onResume() {
        super.onResume()
        if (galleryOpened) {
            CoroutineScope(Dispatchers.Main).launch {
                binding.progressBar.visibility = View.VISIBLE
                val byteArray = convertToBytes(uri)
                val imageString = lowerQuality(byteArray)
                val file = image(imageString)
                showFullImageFromCache(file,imageString)
                binding.progressBar.visibility = View.GONE
                galleryOpened = false
            }
        }
    }

}

