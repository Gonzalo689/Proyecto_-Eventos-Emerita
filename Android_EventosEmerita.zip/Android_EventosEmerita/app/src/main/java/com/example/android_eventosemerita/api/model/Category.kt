package com.example.android_eventosemerita.api.model

/**
 * Representa una categoría de Categorías.
 */
class Category (val name:String ,val busqueda:String , val image: Int ) {
}