package com.example.android_eventosemerita.api.model

class Category (val name:String ,val busqueda:String , val image: Int ) {
}